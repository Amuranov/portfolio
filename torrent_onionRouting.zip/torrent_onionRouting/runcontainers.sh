#!/bin/bash
TERM="terminator -x" # choose your terminal emulator here

# Run tracker
$TERM docker run --net cryptonet --ip 172.18.0.10 -it cryptorrent --tracker --port 33033 -pk files/keys/tracker/private.json &

# Run nodes
$TERM docker run --net cryptonet --ip 172.18.0.20 -it cryptorrent --node --port 33033 -pk files/keys/nodes/0/private.json &
$TERM docker run --net cryptonet --ip 172.18.0.21 -it cryptorrent --node --port 33033 -pk files/keys/nodes/1/private.json &
$TERM docker run --net cryptonet --ip 172.18.0.22 -it cryptorrent --node --port 33033 -pk files/keys/nodes/2/private.json &
$TERM docker run --net cryptonet --ip 172.18.0.23 -it cryptorrent --node --port 33033 -pk files/keys/nodes/3/private.json &
$TERM docker run --net cryptonet --ip 172.18.0.24 -it cryptorrent --node --port 33033 -pk files/keys/nodes/4/private.json &

# Run peers
$TERM docker run --net cryptonet --ip 172.18.0.30 -it cryptorrent --peer --port 33033 -tip 172.18.0.10 -tpk files/keys/tracker/public.json -nf files/nodes.json -f files/peers/0 &
$TERM docker run --net cryptonet --ip 172.18.0.31 -it cryptorrent --peer --port 33033 -tip 172.18.0.10 -tpk files/keys/tracker/public.json -nf files/nodes.json -f files/peers/1 &
