from unittest import TestCase
from solution.infof405 import TcpClient
from solution.infof405 import TcpServer


class TestTcpClient(TestCase):
	
	def test_connect(self):
		port = 33033
		
		server = TcpServer()
		server.bind(port)
		
		client = TcpClient()
		client.connect("127.0.0.1", port)
		
		newconnection = server.waitNewConnection()
		
		self.assertTrue(client.is_connected)
		
		newconnection.close()
		server.close()
		client.close()
