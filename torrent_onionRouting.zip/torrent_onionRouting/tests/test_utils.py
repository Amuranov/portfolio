from unittest import TestCase
from solution.infof405 import Utils


class TestUtils(TestCase):
	
	def test_isNumber(self):
		self.assertTrue(Utils.is_float("50.0"))
		self.assertTrue(Utils.is_float("45"))
		self.assertFalse(Utils.is_float("45a"))
		self.assertFalse(Utils.is_float("a"))
		self.assertFalse(Utils.is_float("10E"))
	
	
	def test_is_prime(self):
		self.assertFalse(Utils.is_prime(1))  # 1: False
		self.assertTrue(Utils.is_prime(2))  # 2: True
		self.assertTrue(Utils.is_prime(3))  # 3: True
		self.assertFalse(Utils.is_prime(4))  # 4: False
		self.assertTrue(Utils.is_prime(5))  # 5: True
		self.assertFalse(Utils.is_prime(6))  # 6: False
		self.assertTrue(Utils.is_prime(7))  # 7: True
		self.assertFalse(Utils.is_prime(8))  # 8: False
		self.assertFalse(Utils.is_prime(9))  # 9: False
		self.assertFalse(Utils.is_prime(10))  # 10: False
