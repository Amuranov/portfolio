from unittest import TestCase

from solution.infof405.DH import *


class TestDH(TestCase):

	def test_shared_secret(self):
		a = DH.gen_secret_int()
		A = DH.compute_public(a)

		b = DH.gen_secret_int()
		B = DH.compute_public(b)

		result = DH.compute_shared_secret(A, b)
		expected = DH.compute_shared_secret(B, a)

		self.assertEqual(result, expected)

	def test_shared_aeskeys(self):
		a = DH.gen_secret_int()
		A = DH.compute_public(a)

		b = DH.gen_secret_int()
		B = DH.compute_public(b)

		result = DH.compute_pairkeynonce(A, b)
		expected = DH.compute_pairkeynonce(B, a)

		self.assertEqual(result.key, expected.key)
		self.assertEqual(result.nonce, expected.nonce)
