from unittest import TestCase
from solution.infof405 import Node


class TestNode(TestCase):
	
	def test_start(self):
		port = 33033
		private_key = None
		node = Node(port, private_key)
		node.start()
		self.assertTrue(node.is_running)
		node.stop()
	
	
	def test_stop(self):
		port = 33033
		private_key = None
		node = Node(port, private_key)
		node.start()
		node.stop()
		self.assertFalse(node.is_running)
