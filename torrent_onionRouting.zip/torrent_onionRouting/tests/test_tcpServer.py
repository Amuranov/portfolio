from unittest import TestCase
from solution.infof405 import TcpClient
from solution.infof405 import TcpServer


class TestTcpServer(TestCase):
	
	def test_bind(self):
		server = TcpServer()
		server.bind(33033)
		self.assertTrue(server.is_connected)
		server.close()
	
	def test_waitNewConnection(self):
		port = 33033
		
		server = TcpServer()
		server.bind(port)
		
		client = TcpClient()
		client.connect("127.0.0.1", port)
		
		newconnection = server.waitNewConnection()
		self.assertIsInstance(newconnection, TcpClient)
		
		newconnection.close()
		server.close()
		client.close()
	
	def test_send(self):
		server = TcpServer()
		server.bind(33033)
		
		client = TcpClient()
		client.connect("127.0.0.1", 33033)
		
		new_connection = server.waitNewConnection()
		
		json_sent = {"message": "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "ip": "528.80.25.5", "port": 33033}
		server.send(json_sent, new_connection)
		
		json_receive = client.receive()
		self.assertDictEqual(json_receive, json_sent)
		
		new_connection.close()
		server.close()
		client.close()
