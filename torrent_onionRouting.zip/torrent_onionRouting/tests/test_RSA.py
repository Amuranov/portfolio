from unittest import TestCase
from solution.infof405.RSA import *
from solution.infof405.Utils import *


class TestRSA(TestCase):

	def test_get_big_prime(self):
		random.seed(54354)
		number_of_prime_to_test = 5000
		max_length_to_test = 10

		primes = []
		for i in range(number_of_prime_to_test):
			for length in range(1, max_length_to_test):
				prime = RSA.get_big_prime(length)
				self.assertIsInstance(prime, int)
				self.assertTrue(Utils.is_prime(prime))  # Vérifie que les nombres sortis sont premiers
				primes.append(prime)

		self.assertTrue(
			len(set(primes)) > 1)  # Vérifie que tous les nombres premiers tirés aléatoirement ne soient pas les mêmes

	def test_generate_keys(self):
		n, e, d = RSA.generate_keys(128)
		m = "hello"
		m_size = len(m)
		mi = int.from_bytes(m.encode(), byteorder='big')
		c = RSA.encrypt(mi, n, e)
		dec = RSA.decrypt_secret_key(c, n, d)
		self.assertEqual(dec.to_bytes(m_size, byteorder='big').decode(), m)

	def test_encrypt_pubkey(self):

		pubkey = Utils.parse_public_key_file("../files/keys/tracker/public.json")
		privkey = Utils.parse_private_key_file("../files/keys/tracker/private.json")

		m = "h" * 2000
		c = RSA.encrypt_string_hybrid(m, pubkey)
		dec = RSA.decrypt_hybrid(c, privkey)
		assert dec == m
