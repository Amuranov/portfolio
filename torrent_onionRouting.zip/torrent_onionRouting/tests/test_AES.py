from unittest import TestCase

from solution.infof405 import *


class TestAES(TestCase):

	def test_global(self):
		state = np.array([
			[0x32, 0x88, 0x31, 0xe0],
			[0x43, 0x5a, 0x31, 0x37],
			[0xf6, 0x30, 0x98, 0x07],
			[0xa8, 0x8d, 0xa2, 0x34]])
		key = np.array([
			[0x2b, 0x28, 0xab, 0x09],
			[0x7e, 0xae, 0xf7, 0xcf],
			[0x15, 0xd2, 0x15, 0x4f],
			[0x16, 0xa6, 0x88, 0x3c]])
		result = AES.aes_encrypt(state, key)

		expected = np.array([
			[0x39, 0x02, 0xdc, 0x19],
			[0x25, 0xdc, 0x11, 0x6a],
			[0x84, 0x09, 0x85, 0x0b],
			[0x1d, 0xfb, 0x97, 0x32]])

		result = result.tolist()
		expected = expected.tolist()

		self.assertListEqual(result, expected)

	def test_aes_ctrmode_encrypt(self):
		pairKeyNonce = PairKeyNonce()

		aesInstance1 = AES(pairKeyNonce)
		aesInstance2 = AES(pairKeyNonce)

		message = "hello" * 100

		result = aesInstance1.aes_ctrmode_encrypt(message.encode())

		decryption = aesInstance2.aes_ctrmode_encrypt(result)

		result = decryption.decode()

		expected = message

		self.assertEqual(result, expected)

	def test_aes_ctrmode_encrypt_file_list(self):
		nb_keys = 4
		files_folder = "../files/peers/0"

		aesEncrypts = []
		aesDecrypts = []
		for i in range(nb_keys):
			pairKeyNonce = PairKeyNonce()
			aesEncrypts.append(AES(pairKeyNonce))
			aesDecrypts.append(AES(pairKeyNonce))

		message = ';'.join(listdir(files_folder))
		message = message.encode()

		for aesEncrypt in reversed(aesEncrypts):
			message = aesEncrypt.aes_ctrmode_encrypt(message)

		print(message)
		message = message.hex()

		for aesDecrypt in aesDecrypts:
			message = bytes.fromhex(message)
			message = aesDecrypt.aes_ctrmode_encrypt(message)
			message = message.hex()

		message = str(bytes.fromhex(message).decode())

		expected = ';'.join(listdir(files_folder))

		self.assertEqual(message, expected)
