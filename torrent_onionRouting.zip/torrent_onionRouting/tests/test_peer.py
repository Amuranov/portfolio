from unittest import TestCase

from infof405 import *


class TestPeer(TestCase):

	def test_choose_random_nodes(self):
		nodesfile = "../files/nodes.json"
		nodes = Utils.parse_nodes_file(nodesfile)

		for size_expected in range(3, 5):
			node_chain = Peer.choose_random_nodes(nodes, size_expected)
			self.assertIsInstance(node_chain, NodeChain)
			self.assertEqual(len(node_chain), size_expected)

	def test_establish_connection(self):
		peer = Peer(33040, "127.0.0.1", "../files/keys/tracker/public.json", "../files/nodes.json", "../files/peers/0")

		peer.establish_connection()

	def test_encrypt_aes_keys(self):
		peer = Peer(33040, "172.18.0.10", "../files/keys/tracker/public.json", "../files/nodes.json",
		            "../files/peers/0")

		nodes_chosen = peer.choose_random_nodes(peer.nodes, 3)
		# --- Create and encrypt_public_key all the AES_keys to be sended ---
		aes_keys = peer.create_aes_keys(peer.tracker_ip, nodes_chosen)
		peer.__aes_keys = aes_keys
		message = peer.encrypt_aes_keys(peer.nodes, nodes_chosen, peer.tracker_ip, peer.tracker_pubkey, aes_keys)

		for node in nodes_chosen:
			privkey = Utils.parse_private_key_file("../files/keys/nodes/" + node[-1] + "/private.json")
			message = RSA.decrypt_hybrid(message, privkey)
			aesKeysEncryptionMsg = AESKeysEncryptionMsg.fromString(message)
			message = aesKeysEncryptionMsg.tuple_crypted

		privkey = Utils.parse_private_key_file("../files/keys/tracker/private.json")
		print("message: " + message.toString())
		message = RSA.decrypt_hybrid(message, privkey)
		print(message)
