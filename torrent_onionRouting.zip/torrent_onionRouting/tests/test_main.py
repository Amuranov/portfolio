from unittest import TestCase
from solution.infof405 import *


class TestMain(TestCase):
	
	def test_main(self):
		tracker = Tracker(33000, "../files/keys/tracker/private.json")
		node0 = Node(33030, "../files/keys/nodes/0/private.json")
		node1 = Node(33031, "../files/keys/nodes/1/private.json")
		node2 = Node(33032, "../files/keys/nodes/2/private.json")
		node3 = Node(33033, "../files/keys/nodes/3/private.json")
		node4 = Node(33034, "../files/keys/nodes/4/private.json")
		peer0 = Peer(33040, "127.0.0.1", "../files/keys/tracker/public.json", "../files/nodes.json", "../files/peers/0")
		peer1 = Peer(33040, "127.0.0.1", "../files/keys/tracker/public.json", "../files/nodes.json", "../files/peers/1")
		
		tracker.start()
		node0.start()
		node1.start()
		node2.start()
		node3.start()
		node4.start()
		peer0.start()
		peer1.start()
		
		self.assertTrue(tracker.is_running)
		self.assertTrue(node0.is_running)
		self.assertTrue(node1.is_running)
		self.assertTrue(node2.is_running)
		self.assertTrue(node3.is_running)
		self.assertTrue(node4.is_running)
		self.assertTrue(peer0.is_running)
		self.assertTrue(peer1.is_running)
		
		time.sleep(1)
		
		peer0.ask_list_of_files()
		
		time.sleep(5)
		
		tracker.stop()
		node0.stop()
		node1.stop()
		node2.stop()
		peer0.stop()
		peer1.stop()
