import time
from unittest import TestCase
from solution.infof405 import Tracker


class TestTracker(TestCase):
	
	def test_start(self):
		tracker = Tracker(33033)
		tracker.start()
		self.assertTrue(tracker.is_running)
		time.sleep(3)
		self.assertTrue(tracker.is_connected)
		tracker.stop()
		self.assertFalse(tracker.is_running)
		self.assertFalse(tracker.is_connected)
