## Combinit Torrents with Onion routing

### Internet and confidentiality

Confidentiality is known as a major issue over public networks like the internet. Since every packet is routed from a peer to another through a sequence of routers mainly belonging to different entities, additional mechanisms should be put in place in order to ensure data privacy during transmission. The most common way to enable confidentiality (and more...) on the internet is to encrypt HTTP traffic using TLS to get the famous HTTPS protocol. The main idea of this protocol is to protect data using hybrid encryption. When a client reach the server, a (signed) key exchange is performed to share a session key and all subsequent communications between both parties are encrypted using a symmetric (authenticated) encryption scheme.
Nevertheless, even if the content of the communication between the parties is now encrypted, someone watching the network could still learn with whom peers are talking. Indeed, the encryption is only applied on the payload of the packets and not on the headers containing the addresses. The reason is that the routing is obviously impossible if the routers are receiving encrypted addresses.

### Onion routing


Onion routing
Onion Routing is a communication procedure aiming at ensuring anonymity over a public network. Ano- nymity in this context means that two peers can communicate with each others without revealing their true identity and an adversary observing the network would have a really hard time guessing which pairs of user are actually communicating together. The sketch of the routing procedure is the following :
Let PKE = (E,D) be a public-key encryption scheme with encryption function E and decryption func- tion D. Each entity on the network holds a key pair composed of a public key pk and a private keys sk and is reachable at an address IP. We use subscripts to denote ownership of those attributes, e.g. the entity A has public key pkA, secret key skA and is found at IPa.
When a client C wants to send a message m to a server S, the following happens :
1. The client picks a set of three routers called nodes A,B,C from a public list shared by the whole network.
1
2. The client encrypts sequentially their message with the public keys of the nodes in order to get a message of the form ct = E((IPB,E((IPC,E((IPS,E(m, pkS)), pkC)), pkB)), pkA)
3. The client sends ct to the entry node A
4. A decrypts the first layer of encryption to get IPB,E((IPC,E((IPS,E(m, pkS)), pkC)), pkB) and for- wards the right part to B. Note that A did not learn anything about neither the content of the message nor the identity of the server.
5. B decrypts the second layer of encryption to get (IPC,E((IPS,E(m, pkS)), pkC)) and forwards to the exit node C. Note that it this point, B does not know anything about sender, receiver nor the content of the message. B only routes from A to C by removing a layer of encryption.
6. C decrypts the third layer of encryption to get (IPS,E(m, pkS)) and forwards it to S. 7. S decrypts and gets the message without learning the address/identity of the client C.
Now that a path between the server and the client is established using three proxy nodes, the connection can resume as a classical HTTP(S) connection. Indeed, each node now knows who is next and previous in the list of routers and can forward accordingly in each directions. In practice, at each step, a symmetric key is exchanged between each participants to avoid all subsequent communications to suffer from the heaviness of asymmetric cryptography. 1

### Project goal 


Goal of the project
In this project, the goal is to create a network in which users can exchange files without learning the identity of the other peers. There exist three types of users :
— The tracker — Nodes
— Peers
The tracker is unique on the network, its goal is to collect information about the ownership of (parts of) files. Every peer participating to the network will start by a connection to the tracker in order to announce the list of file they can share. Its IP is public and well known by everyone. The nodes are regular onion routing nodes, they do not share files, their only purpose is to relay communications between two peers or between a peer and the tracker. Their IP addresses are also all public and well known by the whole network. The peers are the base users of the system, they want to share files with other peers. They communicate with the tracker to transmit their list of files and to make download request from other peers.

At start, a peer p establishes an onion routed connection to the tracker and sends the list of files it owns. The tracker will answer with a list of all the files available through the network. If p wants one of them, the tracker finds the owner of the file (let us call it p′) and links the two exit nodes (the two nodes before him in both chains coming from p and p′) together. This will create a tunnel of 6 nodes between p and p′.

The connection will continue as a normal onion routed connection, the only difference is that we now have 6 nodes between both ends instead of 3. The important property of this system is that at no point the peers revealed their IP addresses to anyone else beside the first node they chose.


### Requirements
- Linux
- Python 3
- Docker

### First run
##### Windows
- Install virtualbox (https://www.virtualbox.org)
- Download `ubuntu server` (here : https://www.ubuntu.com/download/server)
- Continue with Linux section

##### Linux
- `sudo apt-get update && sudo apt-get upgrade`
- Clone the project
- `cd/project_name`
- `sudo snap install docker`
- `sudo docker build --tag cryptorrent .` (Build docker container with python)
- `sudo docker network create --subnet=172.18.0.0/24 cryptonet` (Create subnetwork)
- `nano runcontainers.sh`
- change `TERM="terminator -x"`
- `./runcontainers.sh` (Run all peers, nodes and tracker)

### Summary of entities

- `tracker`
    - is unique ;
    - is the master node ;
    - is known by the `peers`
    - possesses a full list of filenames of the `peers` ( filename → connection to peer )
- `node`
    - is an `onion router`: encrypts/decrypts and relays data
    - its ip and public key is known by the `peers`
- `peer`
    - is the client, and wants to share files anonymously with other `peers` ;
    - knows the ip's and public keys of the `tracker` and `nodes`
    - possesses its own list of files
    - has a small command-line user interface

### Summary of connections :

- `peer1` wants to establish a connection to the `tracker`
    - `peer1` chooses randomly 3 (or +) `nodes`
    - `peer1` generates for every `node` and the `tracker` a 128-bit AES session key and 64 bit nonce for counter mode
    - `peer1` encrypts the AES key + nonce for the tracker with the `tracker's` public key
    - `peer1` adds the ip of the `tracker` and the AES key + nonce of `exit node` and encrypts with the public key of the `exit node`
    - `peer1` adds the ip of the `exit node` and the AES key + nonce of `middle node` and encrypts with the public key of the `middle node`
    - `peer1` adds the ip of the `middle node` and the AES key + nonce of `entry node` and encrypts with the public key of the `entry node`
    - `peer1` sends this connection establishment message to the `entry node`
    - the `entry node` decrypts the message, initializes its session key and nonce, and forwards the ciphertext to the ip of the `middle node`
    - the message is further decrypted and forwarded through the `exit node` until it arrives at the tracker
    - every `node` and the `tracker` have initialized their session key and nonce for this connection with `peer1`
    - from now on, all communication between `peer1` and `tracker` will be `onion routed` through the nodes using AES in counter mode with the shared key and nonce
    - the `tracker` answers with a `connected` message
    - when receiving the `connected` message, `peer1` sends an `ls` message with its list of filenames
    - the `tracker` updates the list of filenames with the corresponding connection
    - the `tracker` sends back an `ls` message containing the names of other files from other peers
- `peer1` wants a specific file
  - `peer1` sends a 'get' message with the filename and a g^a
  - `tracker` finds the connection to the holder of the file `peer2` and forwards the `get` message through that connection to `peer2`
  - `tracker` links the connections so that the file from `peer2` will be forwarded to `peer1`
  - `peer2` receives the `get` message, and sends a `send` message back containing the file encrypted with Diffie-Hellman + the g^b
