# coding=utf-8


if __name__ == "__main__":
	import argparse
	import sys
	from infof405 import *
	
	
	parser = argparse.ArgumentParser()
	parser.add_argument("-t", "--tracker", help="Runs as tracker", action='store_true')
	parser.add_argument("-n", "--node", help="Runs as node", action='store_true')
	parser.add_argument("-p", "--peer", help="Runs as peer", action='store_true')
	parser.add_argument("-po", "--port", type=int, help="Specifies port")
	parser.add_argument("-tip", "--trackerip", type=str, help="Specifies tracker ip")
	parser.add_argument("-tpk", "--trackerpubkeyfile", type=str, help="Specifies tracker public key")
	parser.add_argument("-nf", "--nodesfile", type=str, help="Specifies file with nodes IP and pubkeys")
	parser.add_argument("-pk", "--privkeyfile", type=str, help="Path to file containing private key")
	parser.add_argument("-f", "--folder", type=str, help="Specifies the path to the folder with the files to share")
	args = parser.parse_args()
	
	if args.tracker:
		if args.node:
			Log.error("incompatible arguments [-t --tracker] and [-n --node] choose only one")
			sys.exit(-1)
		if args.peer:
			Log.error("incompatible arguments [-t --tracker] and [-p --peer] choose only one")
			sys.exit(-1)
		if args.port is None:
			Log.error("missing argument port [-p --port] when choosing [-t --tracker]")
			sys.exit(-1)
		if args.privkeyfile is None:
			Log.error("missing argument private key file [-pk --privkeyfile] when choosing [-t --tracker]")
			sys.exit(-1)
		
		tracker = Tracker(args.port, args.privkeyfile)
		tracker.start()
		tracker.join()
	
	if args.node:
		if args.peer:
			Log.error("incompatible arguments [-n --node] and [-p --peer] choose only one")
			sys.exit(-1)
		if args.privkeyfile is None:
			Log.error("missing argument private key file [-pk --privkeyfile] when choosing [-n --node]")
			sys.exit(-1)
		if args.port is None:
			Log.error("missing argument port [-p --port] when choosing [-n --node]")
			sys.exit(-1)
		if args.privkeyfile is None:
			Log.error("missing argument private key file [-pk --privkeyfile] when choosing [-n --node]")
			sys.exit(-1)
		
		node = Node(args.port, args.privkeyfile)
		node.start()
		node.join()
	
	if args.peer:
		if args.trackerip is None:
			Log.error("missing argument [-tip --trackerip] when choosing [-p --peer]")
			sys.exit(-1)
		if args.nodesfile is None:
			Log.error("missing argument [-nf --nodesfile] when choosing [-p --peer]")
			sys.exit(-1)
		if args.folder is None:
			Log.error("missing argument [-f --folder] when choosing [-p --peer]")
			sys.exit(-1)
		if args.port is None:
			Log.error("missing argument [-p --port]when choosing [-p --peer]")
			sys.exit(-1)
		if args.trackerpubkeyfile is None:
			Log.error("missing argument private key file [-tpk --trackerpubkeyfile] when choosing [-p --peer]")
			sys.exit(-1)
		
		peer = Peer(args.port, args.trackerip, args.trackerpubkeyfile, args.nodesfile, args.folder)
		peer.start()
		peer.interface()
		peer.join()
	else:
		Log.error("please give 1 argument between [-t --tracker], [-n --node] and [-p --peer]")
		sys.exit(-1)
	
	Log.add("exit successfully")
	sys.exit(0)
