# coding=utf-8
import sys
import socket as s
import json as j
from .Log import *


class TcpClient:
	"""
	Classe représentant le client tcp, utilisé par le tracker, les nodes et les peers
	"""

	def __init__(self, socket=None):
		if socket is None:
			socket = s.socket(s.AF_INET, s.SOCK_STREAM)
		if not type(socket) is s.socket:
			Log.add("TcpClient invalid type as parameter for the `__init__` function: `socket` expected")
			sys.exit(-1)
		self.__socket = socket
		self.__is_connected = False

	def get_socket(self):
		return self.__socket

	@property
	def is_connected(self):
		"""
		Returns: true if the server is connected on port
		"""
		return self.__is_connected

	def close(self):
		"""
		Stop the server
		"""
		self.__is_connected = False
		try:
			self.__socket.close()
		except:
			pass

	def connect(self, ip: str, port: int):
		"""
		Connecte le client à l'ip et port
		Args:
			ip: string
			port: int
		"""
		Log.add("TcpClient is trying to connect to %s:%i" % (ip, port))
		try:
			self.__socket.connect((ip, port))
			self.__is_connected = True
		except Exception as e:
			Log.error("TcpClient can't connect to %s:%i : %s" % (ip, port, e))
			self.close()
			sys.exit(-1)
		Log.add("TcpClient is connected to %s:%i" % (ip, port))

	def send(self, json):
		"""
		Send json to server
		Args:
			json: dict
		"""
		try:
			json = j.dumps(json)
		except:
			Log.error("TcpClient invalid json as a parameter for the `send` function")
			self.close()
			sys.exit(-1)
		Log.add("TcpClient is trying to send json to server")
		try:
			self.__socket.send(json.encode('utf-8'))
		except:
			Log.error("TcpClient unexpected error when sending json")
			self.close()
			sys.exit(-1)
		Log.add("TcpClient sent json to server")

	def receive(self):
		"""
		Receive json from server
		"""
		json = ""
		while True:
			try:
				data = self.__socket.recv(1024)
				json += data.decode('utf-8')
				json = j.loads(json)
				break
			except:
				pass
		Log.add("TcpClient receive new json")
		return json
