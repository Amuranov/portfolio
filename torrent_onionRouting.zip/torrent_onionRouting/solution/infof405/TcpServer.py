# coding=utf-8
from .TcpClient import *


class TcpServer:
	"""
	Classe représentant le serveur tcp, utilisé par le tracker et les nodes
	"""
	
	
	def __init__(self):
		self.__socket = s.socket(s.AF_INET, s.SOCK_STREAM)
		self.__is_connected = False
		self.__port = None
	
	
	@property
	def is_connected(self):
		"""
		Returns: true if the server is connected on port
		"""
		return self.__is_connected
	
	
	@property
	def port(self):
		"""
		Returns: le numéro du port
		"""
		return self.__port
	
	
	def close(self):
		"""
		Stop the server
		"""
		self.__is_connected = False
		self.__port = None
		try:
			self.__socket.close()
		except:
			pass
	
	
	def bind(self, port: int):
		"""
		Commence à accepter les nouvelles connexions au port donné
		Args:
			port: int
		Returns: True si le serveur a réussi a se connecter
		"""
		Log.add("TcpServer tries to listen on port %i" % port)
		try:
			self.__socket.bind(('', port))
			self.__socket.listen(50)
			self.__is_connected = True
			self.__port = port
			Log.add("TCPServer ip's %s" % (s.gethostbyname(s.gethostname())))
			Log.add("TcpServer is listening on port %i" % port)
			return True
		except Exception:
			Log.error("TcpServer fails to listen on port %i" % port)
			self.close()
			return False
	
	
	def waitNewConnection(self):
		"""
		Fonction bloquante, le serveur attend une nouvelle connexion et renvoie le socket
		Returns: TcpClient
		"""
		Log.add("TcpServer is waiting for a new connection")
		try:
			(socket, (ip, port)) = self.__socket.accept()
			Log.add("TcpServer has accepted a new connection from %s:%i" % (ip, port))
			return TcpClient(socket)
		except Exception as e:
			Log.error("TcpServer close waiting new connection : %s" % e)
			return None
	
	
	def send(self, json: dict, tcpClient: TcpClient):
		"""
		Send json to client
		Args:
			json: dict
			tcpClient: TcpClient
		"""
		tcpClient.send(json)
