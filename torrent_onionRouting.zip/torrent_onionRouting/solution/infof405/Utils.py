# coding=utf-8
import sys
import json as j
import random
import sympy
from .PublicKey import *
from .PrivateKey import *
from .Log import *


class Utils:

	@staticmethod
	def is_int(number):
		try:
			int(number)
			return True
		except:
			return False

	@staticmethod
	def is_float(number):
		try:
			float(number)
			return True
		except:
			return False

	@staticmethod
	def load_json(filename: str):
		with open(filename) as file:
			lines = file.readlines()
		json = None
		try:
			json = "".join(lines)
			json = j.loads(json)
		except:
			Log.error("Bad JSON format for `%s`" % filename)

		return json  # type: list

	@staticmethod
	def parse_nodes_file(filename):
		json = Utils.load_json(filename)  # type: list
		dic = {}  # type: dict
		for node in json:  # type: dict
			try:
				ip = str(node["ip"])  # type: str
				n = int(node["n"])  # type: int
				e = int(node["e"])  # type: int
			except:
				Log.error("Bad format file for `%s`" % filename)
				sys.exit(-1)
			dic[ip] = PublicKey(n, e)  # type: PrivateKey
		return dic  # type: dict

	@staticmethod
	def parse_private_key_file(filename):
		json = Utils.load_json(filename)  # type: dict
		try:
			n = int(json["n"])  # type: int
			d = int(json["d"])  # type: int
		except:
			Log.error("Bad format file for `%s`" % filename)
			sys.exit(-1)
		return PrivateKey(n, d)  # type: PrivateKey

	@staticmethod
	def parse_public_key_file(filename):
		json = Utils.load_json(filename)  # type: dict
		try:
			n = int(json["n"])  # type: int
			e = int(json["e"])  # type: int
		except:
			Log.error("Bad format file for `%s`" % filename)
			sys.exit(-1)
		return PublicKey(n, e)  # type: PrivateKey

	@staticmethod
	def get_big_prime(length: int):
		p = random.getrandbits(length)
		p = p | 1
		while not sympy.isprime(p):
			p += 2
		return p
