class PrivateKey:

	def __init__(self, n, d):
		self.__n = n
		self.__d = d

	@property
	def n(self):
		return self.__n

	@property
	def d(self):
		return self.__d
