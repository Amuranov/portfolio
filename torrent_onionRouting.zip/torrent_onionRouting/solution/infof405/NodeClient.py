# coding=utf-8
from .TcpClient import *
from .AES import *
from .RSA import *
from .AESKeysEncryptionMsg import *
from threading import Thread


class NodeClient:
	"""
	Représente une connexion tcp recue par le node
	"""

	def __init__(self, socket, private_key):
		if not isinstance(socket, TcpClient):
			Log.add("NodeClient invalid socket type as parameter")
			sys.exit(-1)
		Log.add("NodeClient creation")
		self.__running = False
		self.__socket = socket
		self.__next_socket = None
		self.__thread = None
		self.__thread_back = None
		self.__private_key = private_key
		self.__aes_key = None

	def start(self):
		self.__running = True
		message = self.__socket.receive()

		# --- Decrypt the message and gather ip , aes_key and message
		aesKeysEncryptionMsg: AESKeysEncryptionMsg = self.decrypt(RSACiphertext.fromString(message["message"]))
		Log.add("NodeClient aeskeysencmsg message: " + str(aesKeysEncryptionMsg))
		Log.add("NodeClient aeskeysencmsg message key: " + str(aesKeysEncryptionMsg.pairkeynonce.key))
		Log.add("NodeClient aeskeysencmsg message nonce: " + str(aesKeysEncryptionMsg.pairkeynonce.nonce))
		Log.add("NodeClient aeskeysencmsg message next_ip: " + str(aesKeysEncryptionMsg.next_ip))
		Log.add("NodeClient aeskeysencmsg message tuple: " + str(aesKeysEncryptionMsg.tuple_crypted))
		self.__aes_key = AES(aesKeysEncryptionMsg.pairkeynonce)

		# --- Establish the connection with the next node
		self.__next_socket = TcpClient()
		port = 33033  # type: int
		self.__next_socket.connect(aesKeysEncryptionMsg.next_ip, port)
		self.__next_socket.send({"message": aesKeysEncryptionMsg.tuple_crypted.toString()})

		self.__thread = Thread(target=self.__threadListen)
		self.__thread.start()
		self.__thread_back = Thread(target=self.__threadListenBack)
		self.__thread_back.start()

	def decrypt(self, message: RSACiphertext):
		"""
		Decrypt the message crypted with RSA , and gather all the informations

		:param message: RSA message
		:return: ip of the next node ; AES key for the peer and this node ; message still crypted
		"""
		sentence = RSA.decrypt_hybrid(message, self.__private_key)
		aesKeysEncryptionMsg = AESKeysEncryptionMsg.fromString(sentence)
		return aesKeysEncryptionMsg

	def join(self):
		try:
			self.__thread.join()
		except:
			pass

	def __threadListen(self):
		"""
		Transmit the message from socket to next_socket , with decryption AES in counter mode
		"""
		while self.__running:
			message = self.__socket.receive()
			new_message = self.__aes_key.aes_ctrmode_encrypt(bytes.fromhex(message["message"]))
			self.__next_socket.send({"message": new_message.hex()})
			Log.add("Transmit message forward between nodes")

	def __threadListenBack(self):
		"""
		Transmit the message from next_socket to socket , with encryption AES in counter mode
		"""
		while self.__running:
			message = self.__next_socket.receive()

			if message["message"].startswith("link:"):
				continue
			else:
				new_message = self.__aes_key.aes_ctrmode_encrypt(bytes.fromhex(message["message"]))
				self.__socket.send({"message": new_message.hex()})
				Log.add("Transmit message back between nodes")
