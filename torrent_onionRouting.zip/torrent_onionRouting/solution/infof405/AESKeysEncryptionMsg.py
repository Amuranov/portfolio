from .RSACiphertext import *
from .PairKeyNonce import *


class AESKeysEncryptionMsg:
	'''
	Class representing the message at the nodes used when establishing a connection to the tracker through the nodes.
	An AESKeysEncryptionMsg (after decryption of the initial received ciphertext with RSA with the private key of the
	receiving node), contains the AES key and nonce (self.__pairkeynonce) that will be used,
	a ciphertext (self.__tuple_crypted), and the next_ip to forward the ciphertext to
	'''

	def __init__(self, next_ip: str, tuple_crypted: RSACiphertext, pairkeynonce: PairKeyNonce):
		self.__next_ip = next_ip
		self.__tuple_crypted = tuple_crypted
		self.__pairkeynonce = pairkeynonce

	@property
	def next_ip(self):
		return self.__next_ip

	@property
	def tuple_crypted(self):
		return self.__tuple_crypted

	@property
	def pairkeynonce(self):
		return self.__pairkeynonce

	def toString(self):
		return "%s;%s;%s" % (self.next_ip, self.tuple_crypted.toString(), self.pairkeynonce.toString())

	@staticmethod
	def fromString(string: str):
		next_ip = string.split(';')[0]
		tuple_crypted = RSACiphertext.fromString(string.split(';')[1])
		pairkeynonce = PairKeyNonce.fromString(';'.join(string.split(';')[2:]))
		aesKeysEncryptionMsg = AESKeysEncryptionMsg(next_ip, tuple_crypted, pairkeynonce)
		return aesKeysEncryptionMsg
