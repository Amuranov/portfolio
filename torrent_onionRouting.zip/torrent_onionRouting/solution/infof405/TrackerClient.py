# coding=utf-8
from .AES import *
from .RSA import *
from .TcpClient import *
from .PairKeyNonce import *
from threading import Thread
from ast import literal_eval


class TrackerClient:
	"""
	Représente une connexion tcp recue par le tracker
	"""

	def __init__(self, tcp_client, private_key, main_queue, thread_queue, thread_queue_id):
		if not type(tcp_client) is TcpClient:
			Log.add("TrackerClient invalid socket type as parameter, `TcpClient` expected")
			sys.exit(-1)
		Log.add("TrackerClient creation")
		self.__is_running = False
		self.__tcp_client = tcp_client
		self.__thread_receive = None
		self.__thread_queue_receive = None
		self.__private_key = private_key
		self.__aes_key = None
		self.__list_of_files = None
		self.__tracker_queue = main_queue
		self.__thread_queue = thread_queue
		self.__thread_queue_id = thread_queue_id

	@property
	def is_running(self):
		"""
		Public read only
		Returns: Vrai si les threads sont occupés à travailler
		"""
		return self.__is_running

	def start(self):
		"""
		Lance les threads du Node
		"""
		if not self.is_running:
			# --- Establish the connection and get his AES key
			message = self.__tcp_client.receive()
			pairKeyNonce = self.decrypt(message)
			self.__aes_key = AES(pairKeyNonce)
			# --- Read the receive
			self.__is_running = True
			self.__thread_receive = Thread(target=self.__thread_receive_fct)
			self.__thread_receive.start()
			self.__thread_queue_receive = Thread(target=self.__thread_queue_receive_fct)
			self.__thread_queue_receive.start()
			# send 'connected' message
			answer = "connected:true"
			reply_message = self.__aes_key.aes_ctrmode_encrypt(answer.encode())
			self.__tcp_client.send({"message": reply_message.hex()})

	def stop(self):
		"""
		Demande de fermer les threads du Peer
		"""
		self.__is_running = False
		self.__tcp_client.close()
		self.join()

	def join(self):
		"""
		Attends que les threads du Node se termine
		"""
		try:
			self.__thread_receive.join()
			self.__thread_queue_receive.join()
		except:
			pass

	def __thread_receive_fct(self):
		"""
		Read the incoming message in a thread
		"""
		while self.is_running:
			message = self.__tcp_client.receive()
			new_message = self.__aes_key.aes_ctrmode_encrypt(bytes.fromhex(message["message"]))
			new_message = new_message.decode()

			Log.add("TrackerClient received new message: " + new_message)

			[mode, content] = new_message.split(':', 1)

			if mode == "ls" or mode == "get" or mode == "send":
				queue_message = {"queue_id": self.__thread_queue_id, "mode": mode, "message": content}
				queue_message = str(queue_message).encode()
				self.__tracker_queue.put(queue_message)

	def __thread_queue_receive_fct(self):
		"""
		Read the incoming request by the pipe (Queue)
		"""
		while self.is_running:
			answer = self.__thread_queue.get(True)
			Log.add("TrackerClient " + str(self.__thread_queue_id) + " received from queue:" + str(answer))
			if answer.startswith("link:"):
				self.__tcp_client.send({"message": answer})
			else:
				reply_message = self.__aes_key.aes_ctrmode_encrypt(answer.encode())
				self.__tcp_client.send({"message": reply_message.hex()})

		if self.is_running == False:
			Log.add("TrackerClient Queue stopped")
			queue_message = {"queue_id": self.__thread_queue_id, "mode": "stop", "message": ""}
			queue_message = str(queue_message).encode()
			self.__tracker_queue.put(queue_message)

	def decrypt(self, message):
		"""
		Decrypt the message crypted with RSA , and gather all the informations

		:param message: RSA message
		:return: AES key for the peer and this node ; message clear
		"""
		sentence = RSA.decrypt_hybrid(RSACiphertext.fromString(message["message"]), self.__private_key)

		try:
			pairKeyNonce = PairKeyNonce.fromString(sentence)
		except:
			Log.add("TrackerClient received a message of wrong format")
			sys.exit(-1)

		Log.add("TrackerClient received a aes_key: " + str(pairKeyNonce.key))
		Log.add("TrackerClient received a aes_nonce: " + str(pairKeyNonce.nonce))

		return pairKeyNonce
