# coding=utf-8

from threading import Thread
from .Config import *
from .Utils import *
from .Log import *
from .TcpServer import *
from .TrackerClient import *
from .NodeClient import *
import socket


class Node:

	def __init__(self, port, private_key_filename: str):
		Log.add("Node creation")
		Log.add("Node with IP: %s" % socket.gethostbyname(socket.gethostname()))
		self.__port = port
		self.__private_key = Utils.parse_private_key_file(private_key_filename)
		self.__is_running = False
		self.__tcp_client = TcpClient()
		self.__tcp_server = TcpServer()
		self.__thread_listen = Thread(target=self.__thread_listen_fct)

	@property
	def is_running(self):
		"""
		Returns: Vrai si les threads sont occupés à travailler
		"""
		return self.__is_running

	@property
	def port(self):
		"""
		Returns: Le numero du port
		"""
		return self.__port

	def start(self):
		"""
		Lance les threads du Node
		"""
		if not self.is_running:
			self.__is_running = True
			self.__thread_listen.start()

	def stop(self):
		"""
		Demande de fermer les threads du Node
		"""
		self.__is_running = False
		self.__tcp_server.close()
		self.__tcp_client.close()
		self.join()

	def join(self):
		"""
		Attends que les threads du Node se termine
		"""
		try:
			self.__thread_listen.join()
		except:
			pass

	def __thread_listen_fct(self):
		"""
		Est le thread d'écoute de nouvelles connexions sur le port
		"""
		Log.add("Node tries to listen on port %i" % self.port)
		if not self.__tcp_server.bind(self.port):
			Log.error("Node fails to listen on port %i" % self.port)
			sys.exit(-1)
		Log.add("Node is listening on port %i" % self.port)
		while self.__is_running:
			tcp_client = self.__tcp_server.waitNewConnection()
			if tcp_client:
				client = NodeClient(tcp_client, self.__private_key)
				client.start()
			else:
				self.stop()
		Log.add("Node stop listening")

	def connect(self, ip: str, port: int):
		"""
		Connecte le node à l'ip et port demandé
		Args:
			ip: str
			port: int
		Returns: Vrai si il est arrivé à se connecter
		"""
		try:
			self.__tcp_client.connect(ip, port)
		except:
			Log.add("Node fails to connect on %s:%i" % (ip, port))

		return self.__tcp_client.is_connected
