# coding=utf-8
from threading import Thread
from .Config import *
from .TcpServer import *
from .TrackerClient import *
from .Log import *
from .Utils import *
import socket
from queue import Queue
from random import randint
from ast import literal_eval


class Tracker:

	def __init__(self, port: int, private_key_filename: str):
		Log.add("Tracker creation")
		Log.add("Tracker with IP: %s" % socket.gethostbyname(socket.gethostname()))
		self.__port = port
		self.__private_key = Utils.parse_private_key_file(private_key_filename)  # type: PrivateKey
		self.__is_running = False
		self.__tcp_client = TcpClient()
		self.__tcp_server = TcpServer()
		self.__thread_listen = None
		self.__thread_queue = None
		self.__list_of_files = {}
		self.__queue = None
		self.__queue_children = {}
		self.__queue_links = {}
		self.__dict_queueid_nodeip = {}  # refactor eventually

	@property
	def is_running(self):
		"""
		Public read only
		Returns: Vrai si les threads sont occupés à travailler
		"""
		return self.__is_running

	@property
	def is_connected(self):
		"""
		Public read only
		Returns: Vrai si le serveur est connecté
		"""
		return self.__tcp_server.is_connected

	@property
	def port(self):
		"""
		Public read only
		Returns: Le numero du port
		"""
		return self.__port

	def start(self):
		"""
		Lance les threads du Node
		"""
		if not self.is_running:
			self.__is_running = True
			Log.add("Tracker initialize his queue ...")
			self.__queue = Queue()
			self.__thread_listen = Thread(target=self.__thread_listen_fct)
			self.__thread_listen.start()
			self.__thread_queue = Thread(target=self.__thread_queue_fct)
			self.__thread_queue.start()

	def stop(self):
		"""
		Demande de fermer les threads du Peer
		"""
		self.__is_running = False
		self.__tcp_client.close()
		self.__tcp_server.close()
		self.join()

	def join(self):
		"""
		Attends que les threads du Node se termine
		"""
		try:
			self.__thread_listen.join()
		except:
			pass

	def __thread_listen_fct(self):
		"""
		Est le thread d'écoute de nouvelles connexions sur le port
		"""
		Log.add("Tracker tries to listen on port %i" % self.port)
		if not self.__tcp_server.bind(self.port):
			Log.error("Tracker fails to listen on port %i" % self.port)
			self.stop()
		Log.add("Tracker is listening on port %i" % self.port)
		while self.is_running:
			tcp_client = self.__tcp_server.waitNewConnection()
			if tcp_client:
				queue_id = self.get_reserved_queue_id()
				self.__queue_children[queue_id] = Queue()
				client = TrackerClient(tcp_client, self.__private_key,
				                       main_queue=self.__queue,
				                       thread_queue=self.__queue_children[queue_id],
				                       thread_queue_id=queue_id)
				self.__dict_queueid_nodeip[queue_id] = tcp_client.get_socket().getpeername()
				Log.add("Queueid_nodeip: " + str(self.__dict_queueid_nodeip))
				client.start()
			else:
				self.stop()
		Log.add("Tracker stop listening")

	def __thread_queue_fct(self):
		"""
		Thread d'écoute pour les requetes contenue dans la queue
		"""
		Log.add("Tracker reading queue ...")
		while self.is_running:
			request = self.__queue.get(True)
			request = literal_eval(request.decode())
			dest_queue_id = request["queue_id"]
			request_mode = request["mode"]
			request_message = request["message"]
			if request_mode == "ls":
				files_list = request_message.split(';')
				self.update_list_of_files(dest_queue_id, files_list)
				# only take file_names from other queue_ids
				list_of_files = {key: val for key, val in self.__list_of_files.items() if val != dest_queue_id}
				reply = ("ls:" + ";".join(list_of_files.keys()))
				self.__queue_children[dest_queue_id].put(reply, True)
			elif request_mode == "get":
				[file_name, DH_ga_str] = request_message.rsplit(',', 1)
				file_queue_id = self.__list_of_files[file_name]
				Log.add("Tracker: file get request of filename: " + file_name + " with queue_id: " + str(file_queue_id))
				(ip, port) = self.__dict_queueid_nodeip[file_queue_id]
				reply = ("link:" + str(ip) + "," + str(port))
				self.__queue_children[file_queue_id].put(reply, True)

				reply = ("get:" + file_name + "," + DH_ga_str)
				self.__queue_children[file_queue_id].put(reply, True)

				self.__queue_links[file_queue_id] = dest_queue_id  # add link locally
			elif request_mode == "send":
				file_content = request_message
				Log.add("Tracker: file content forwarding")
				reply = ("send:" + file_content)
				requested_queue_id = self.__queue_links[dest_queue_id]
				del self.__queue_links[dest_queue_id]
				self.__queue_children[requested_queue_id].put(reply, True)
			elif request_mode == "stop":
				Log.add("Tracker: Queue "+dest_queue_id+" stopped")
				del self.__queue_children[dest_queue_id]

	def get_reserved_queue_id(self):
		"""
		Get an unique index for the queue_id
		"""
		x = randint(1, 1000000)
		while x in self.__queue_children:
			x = randint(1, 1000000)
		return x

	def update_list_of_files(self, queue_id, files_list):
		"""
		Update the list of files contained inside the tracker

		:param queueID: ID of the thread Queue linked to those files
		:param message: string with the files available
		"""
		# remove files that queue_id doesn't have anymore
		self.__list_of_files = {key: val for key, val in self.__list_of_files.items()
		                        if val != queue_id or (val == queue_id) and (key in files_list)}
		# add filename to list_of_files only if not already present
		for file_name in files_list:
			if file_name not in self.__list_of_files.keys():
				self.__list_of_files[file_name] = queue_id

		print("Tracker updated list of files: " + str(self.__list_of_files))
