class RSACiphertext:
	'''
	Class representing a ciphertext using hybrid encryption: RSA(pk, m) = AES(k, m) || RSA(pk, k)
	self.__aes_enc : AES(k, m)
	self.__rsa_enc : RSA(pk, k)
	'''

	def __init__(self, aes_enc: bytes, rsa_enc: int, rsa_enc_len: int):
		self.__aes_enc = aes_enc
		self.__rsa_enc = rsa_enc
		self.__rsa_enc_len = rsa_enc_len

	@property
	def aes_enc(self):
		return self.__aes_enc

	@property
	def rsa_enc(self):
		return self.__rsa_enc

	@property
	def rsa_enc_len(self):
		return self.__rsa_enc_len

	def toString(self):
		return self.aes_enc.hex() + "|" + str(self.rsa_enc) + "|" + str(self.rsa_enc_len)

	@staticmethod
	def fromString(string: str):
		[aes_enc_str, rsa_enc_str, rsa_enc_len_str] = string.split('|')
		aes_enc = bytes.fromhex(aes_enc_str)
		rsa_enc = int(rsa_enc_str)
		rsa_enc_len = int(rsa_enc_len_str)
		return RSACiphertext(aes_enc, rsa_enc, rsa_enc_len)
