import random


class PairKeyNonce:
	'''
	Represents a pair of an aes key and nonce used with counter mode
	'''

	def __init__(self, key=None, nonce=None):
		if key is None:
			self.__key = random.getrandbits(128)
		else:
			self.__key = key
		if nonce is None:
			self.__nonce = random.getrandbits(64)
		else:
			self.__nonce = nonce

	@property
	def key(self):
		return self.__key

	@property
	def nonce(self):
		return self.__nonce

	def toString(self):
		return "%i;%i" % (self.key, self.nonce)

	@staticmethod
	def fromString(string: str):
		splitted = string.split(';')
		key = int(splitted[0])
		nonce = int(splitted[1])
		pairkeynonce = PairKeyNonce(key, nonce)
		return pairkeynonce
