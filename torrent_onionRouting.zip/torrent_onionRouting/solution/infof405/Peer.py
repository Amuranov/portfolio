# coding=utf-8

from os import listdir, getcwd
from random import randint
from .NodeChain import *
from .PairKeyNonce import *
from .DH import *
from .RSA import *
from .TcpClient import *
from .AES import *
from .AESKeysEncryptionMsg import *
from .Utils import *
import socket


class Peer:

	def __init__(self, port: int, tracker_ip: str, tracker_public_key_filename: str, nodes_filename: str, folder: str):
		Log.add("Peer creation")
		self.__port = port  # type: int
		self.__tracker_ip = tracker_ip  # type: str
		self.__tracker_pubkey = Utils.parse_public_key_file(tracker_public_key_filename)  # type: PublicKey
		self.__nodes = Utils.parse_nodes_file(nodes_filename)
		self.__folder = folder
		self.__is_running = False
		self.__aes_keys = None
		self.__nodes_chain = None
		self.__tcp_client = TcpClient()
		self.__thread_receive = None
		self.__is_ready = False
		self.__DH_a = None
		self.__DH_b = None
		self.__waiting_answer = False
		Log.add("Peer with IP: %s" % socket.gethostbyname(socket.gethostname()))
		Log.add("Peer using tracker with IP: %s" % tracker_ip)
		Log.add("Peer using nodes: %s" % str(self.__nodes))
		Log.add("Peer using files folder path: %s" % folder)
		Log.add("Peer files folder containing: %s" % str(listdir(folder)))

	@property
	def is_running(self):
		"""
		:return: int : Vrai si les threads sont occupés à travailler
		"""
		return self.__is_running

	@property
	def port(self):
		"""
		:return: int : Le numero du port
		"""
		return self.__port

	@property
	def tracker_ip(self):
		"""
		:return: str : L'ip du tracker utilisé
		"""
		return self.__tracker_ip

	@property
	def tracker_pubkey(self):
		"""
		:return: str : L'ip du tracker utilisé
		"""
		return self.__tracker_pubkey

	@property
	def nodes(self):
		"""
		:return: str : L'ip du tracker utilisé
		"""
		return self.__nodes

	@property
	def tcp_client(self):
		"""
		:return: TcpClient : Le client tcp qui se connecte au node d'entrée
		"""
		return self.__tcp_client

	def start(self):
		"""
		Lance les threads du Peer
		"""
		if not self.is_running:
			Log.add("Peer is started")
			self.__is_running = True
			self.establish_connection()
			self.__thread_receive = Thread(target=self.__thread_receive_fct)
			self.__thread_receive.start()

	def stop(self):
		"""
		Demande de fermer les threads du Peer
		"""
		self.__is_running = False
		self.tcp_client.close()
		self.join()

	def join(self):
		"""
		Attends que les threads du Node se termine
		"""
		try:
			self.__thread_receive.join()
		except:
			pass

	def __thread_receive_fct(self):
		while self.is_running:
			message = self.__tcp_client.receive()
			# --- Decrypt the data
			data = self.decryptMessage(bytes.fromhex(message["message"]), self.__aes_keys)
			Log.add("Get message: " + str(data))
			data = data.decode()
			Log.add("Get message: " + data)
			[mode, content] = data.split(':', 1)
			if mode == "connected" and content == "true":
				file_list = 'ls:' + ';'.join(listdir(self.__folder))
				self.send_command(file_list)
			elif mode == "get":  #  -- Send file content to another peer --
				self.share_file(content)
			elif mode == "send": #  -- Receive file content from another peer --
				self.receive_file(content)
			elif mode == "ls":
				print("Files: " + content)
				self.__waiting_answer = False

	def establish_connection(self):
		if not self.tcp_client.is_connected:
			self.__nodes_chain = self.choose_random_nodes(self.__nodes, 3)
			# --- Create and encrypt_public_key all the AES_keys to be sended ---
			self.__aes_keys = self.create_aes_keys(self.tracker_ip, self.__nodes_chain)
			message = self.encrypt_aes_keys(self.__nodes, self.__nodes_chain, self.tracker_ip, self.__tracker_pubkey,
			                                self.__aes_keys)
			# --- Start the connexion
			ip = self.__nodes_chain[0]  # type : strs
			port = 33033  # type: int
			self.__tcp_client.connect(self.__nodes_chain[0], port)
			self.__tcp_client.send({"message": message.toString()})
			self.__is_ready = True  # this here?

	def get_nodes_path(self):
		"""
		Renvoie une liste des 3 Nodes qui forment son chemin vers le Tracker
		"""
		return self.__nodes_chain

	@staticmethod
	def choose_random_nodes(nodes: dict, number: int):
		"""
		Return 'numb' random nodes that are going to be used

		:param nodes:
		:param number: Integer (min 3) ; Number of nodes to choose
		:return: array containing IP's of the nodes
		"""
		node_chain = NodeChain()  # type: NodeChain
		max_number_of_nodes = len(nodes)

		# --- Verification of the number of nodes asked ---
		if number < 3:
			Log.error("Wrong number of nodes, Minimum 3 expected")
			number = 3
		elif number > max_number_of_nodes:
			Log.error("Number of nodes above the possibilities")
			number = max_number_of_nodes

		# --- Keep 'number' nodes in the dict ---
		nodes_keys = list(nodes.keys())
		while len(node_chain) < number:
			node_id = randint(0, max_number_of_nodes - 1)
			if nodes_keys[node_id] not in list(node_chain):
				node_chain.append(nodes_keys[node_id])

		Log.add("Nodes chain:" + str(node_chain))

		return node_chain  # type: NodeChain

	@staticmethod
	def create_aes_keys(tracker_ip: str, nodes_chosen: NodeChain):
		"""
		Generate 'number' AES keys

		:param tracker_ip:
		:param nodes_chosen: array ; 'proxy' nodes
		:return: array containing AES keys
		"""
		aes_keys = {}
		for ip in nodes_chosen:  # AES Keys for Nodes
			pairKeyNonce = PairKeyNonce()
			aes_keys[ip] = AES(pairKeyNonce)
		pairKeyNonce = PairKeyNonce()
		aes_keys[tracker_ip] = AES(pairKeyNonce)  # AES Key for Tracker

		return aes_keys

	@staticmethod
	def encrypt_aes_keys(nodes, nodes_chain: NodeChain, tracker_ip: str, tracker_pubkey: PublicKey, aes_keys: dict):
		"""
		Encrypt the AES Keys to be send (Onioning)

		:param tracker_pubkey:
		:param nodes:
		:param tracker_ip:
		:param aes_keys: array-copy containing the AES keys craeted by self.createAESKeys
		:return: ips of the nodes ordered by their access ; AES Keys encrypted
		"""
		aesKey = aes_keys[tracker_ip]
		message = PairKeyNonce(aesKey.key, aesKey.nonce).toString()
		tuple_crypted = RSA.encrypt_string_hybrid(message, tracker_pubkey)  # Deepest encrypted message
		Log.add("Tuple crypted: " + str(tuple_crypted))
		next_ip = tracker_ip

		for ip in reversed(nodes_chain):
			aesKey = aes_keys[ip]
			pairKeyNonce = PairKeyNonce(aesKey.key, aesKey.nonce)
			aesKeysEncryptionMsg = AESKeysEncryptionMsg(next_ip, tuple_crypted, pairKeyNonce)
			message = aesKeysEncryptionMsg.toString()
			tuple_crypted = RSA.encrypt_string_hybrid(message, nodes[ip])
			Log.add("Tuple crypted: " + str(tuple_crypted))
			next_ip = ip

		return tuple_crypted

	def encryptMessage(self, message: bytes, keys, with_tracker: bool):
		"""
		Encrypt with AES the message (file for example) sended to the tracker

		:param message: file/string
		:param keys: keys created at the beginning of the connection
		:return: crypted with AES
		"""
		message = keys[self.tracker_ip].aes_ctrmode_encrypt(message)

		for ip in reversed(self.__nodes_chain):
			message = keys[ip].aes_ctrmode_encrypt(message)

		return message

	def decryptMessage(self, message: bytes, keys):
		"""
		Decrypt the AES ciphered message

		:param message: message transmited from tracker
		:param keys: list of the AES keys
		:return: JSON with data
		"""
		for ip in self.__nodes_chain:
			message = keys[ip].aes_ctrmode_encrypt(message)

		try:
			message.decode()
		except:
			message = keys[self.tracker_ip].aes_ctrmode_encrypt(message)

		return message

	def interface(self):
		help = "\nquit (q) : stop the peer\n" \
		       "help (h) : show this help message\n" \
		       "ls : send own files and ask list of files\n" \
		       "get <filename>: download file"
		message = "Enter your cmd: "
		print(help)
		cmd = input(message).lower()  # type: str

		while cmd != "q":

			if cmd == "h" or cmd == "help":
				print(help)
			elif cmd == "ls":
				file_list = 'ls:' + ';'.join(listdir(self.__folder))
				self.send_command(file_list)
				self.__waiting_answer = True
			elif cmd.startswith("get "):
				filename = cmd.split(' ', 1)[1]
				self.__DH_a = DH.gen_secret_int()
				DH_ga = DH.compute_public(self.__DH_a)
				file_request = "get:" + filename + "," + str(DH_ga)
				self.send_command(file_request)
				self.__waiting_answer = True
			# busy loop until self.__waiting_answer is False
			while True:
				if self.__waiting_answer == False:
					break
			cmd = input(message).lower()

	def send_command(self, command: str, enc_with_tracker=True):
		if self.__is_ready:
			command = command.encode()
			# --- Encrypt the data with AES
			message = self.encryptMessage(command, self.__aes_keys, with_tracker=enc_with_tracker)
			self.__tcp_client.send({"message": message.hex()})  # sending bytes as hex

	def share_file(self, content):
		[file_name, DH_ga_str] = content.split(',')
		DH_ga = int(DH_ga_str)
		Log.add("Sharing file: " + file_name)
		file_content = open(self.__folder + "/" + file_name, 'r').read()
		# Diffie-Hellman encryption
		self.__DH_b = DH.gen_secret_int()
		pairKeyNonce = DH.compute_pairkeynonce(DH_ga, self.__DH_b)
		aes = AES(pairKeyNonce)
		file_content_enc = aes.aes_ctrmode_encrypt(file_content.encode())
		DH_gb = DH.compute_public(self.__DH_b)
		command = "send:" + file_content_enc.hex() + "," + str(DH_gb)
		self.send_command(command, enc_with_tracker=True)  # False when not through tracker

	def receive_file(self, content):
		[file_content_enc_ashex, DH_gb_str] = content.rsplit(',', 1)
		file_content_enc = bytes.fromhex(file_content_enc_ashex)
		# Diffie-Hellman decryption
		DH_gb = int(DH_gb_str)
		pairKeyNonce = DH.compute_pairkeynonce(DH_gb, self.__DH_a)
		aes = AES(pairKeyNonce)
		file_content = aes.aes_ctrmode_encrypt(file_content_enc).decode()
		print("File content: " + file_content)

		save_input = ""
		while save_input not in ["y","n"]:
			save_input = input("Do you wish to save the file ? (y/n)")
			if save_input == "y":
				filename = "test"
				new_file = open(filename, 'w')
				new_file.write(file_content)
				Log.add(filename+" saved on this computer")
				Log.add("location :"+ getcwd())

		self.__waiting_answer = False
