import random
import math
import sympy
import egcd

from .PublicKey import *
from .PrivateKey import *
from .RSACiphertext import *
from .PairKeyNonce import *
from .AES import *
from .Utils import *


class RSA:

	@staticmethod
	def encrypt_string_hybrid(message: str, pubkey: PublicKey):
		pairKeyNonce = PairKeyNonce()
		pairKeyNonce_bytes = pairKeyNonce.toString().encode("utf-8")
		pairKeyNonce_len = len(pairKeyNonce_bytes)
		rsa_enc = RSA.encryptBytes(pairKeyNonce_bytes, pubkey)

		aes = AES(pairKeyNonce)
		aes_enc = aes.aes_ctrmode_encrypt(message.encode("utf-8"))

		return RSACiphertext(aes_enc, rsa_enc, pairKeyNonce_len)

	@staticmethod
	def decrypt_hybrid(ciphertext: RSACiphertext, privkey: PrivateKey):
		pairKeyNonce_int = RSA.decrypt(ciphertext.rsa_enc, privkey)
		pairKeyNonce_str = pairKeyNonce_int.to_bytes(ciphertext.rsa_enc_len, byteorder="big").decode()
		pairKeyNonce = PairKeyNonce.fromString(pairKeyNonce_str)

		aes = AES(pairKeyNonce)
		decrypted = aes.aes_ctrmode_encrypt(ciphertext.aes_enc).decode()

		return decrypted

	@staticmethod
	def encryptBytes(message: bytes, pubkey: PublicKey):
		m = int.from_bytes(message, byteorder='big')
		return RSA.encrypt(m, pubkey)

	@staticmethod
	def encrypt(message: int, pubkey: PublicKey):
		"""
		:param message: int
		:param pubkey: PublicKey
		:return: encryption: int
		"""
		return pow(message, pubkey.e, pubkey.n)

	@staticmethod
	def decrypt_string(message: str, privkey: PrivateKey):
		m = message.encode("utf-8")
		return RSA.decryptBytes(m, privkey)

	@staticmethod
	def decryptBytes(message: bytes, privkey: PrivateKey):
		m = int.from_bytes(message, byteorder='big')
		return RSA.decrypt(m, privkey)

	@staticmethod
	def decrypt(message: int, privkey: PrivateKey):
		"""
		:param message: int
		:param privkey: PrivateKey
		:return: decryption: int
		"""
		return pow(message, privkey.d, privkey.n)

	@staticmethod
	def generate_keys(length):
		"""
		Generate RSA keys
		:param length: int, bitlength of RSA keys
		:return: n, e, d
		"""
		p = Utils.get_big_prime(length // 2)
		q = Utils.get_big_prime(length // 2)

		n = p * q
		phi_n = (p - 1) * (q - 1)

		e = random.randint(2, phi_n - 1)
		while not math.gcd(e, phi_n) == 1:
			e = random.randint(2, phi_n - 1)

		_, x, _ = egcd.egcd(e, phi_n)
		d = x % phi_n

		return n, e, d
