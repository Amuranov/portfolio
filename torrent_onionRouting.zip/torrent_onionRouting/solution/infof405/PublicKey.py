class PublicKey:

	def __init__(self, n, e):
		self.__n = n
		self.__e = e

	@property
	def n(self):
		return self.__n

	@property
	def e(self):
		return self.__e
