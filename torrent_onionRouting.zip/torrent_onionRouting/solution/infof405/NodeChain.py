from .Node import *


class NodeChain(list):
	"""
	Représente la chaine de node qui relie le peer au tracker
	"""
	
	
	def __init__(self):
		super().__init__()
	
	
	def append(self, node: Node):
		if node is Node or True:
			super().append(node)
		else:
			raise AttributeError("`Node` type is expected, get `%s`" % type(node).__name__)
