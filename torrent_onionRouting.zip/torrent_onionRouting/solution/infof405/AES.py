import numpy as np
import math
from .PairKeyNonce import *

np.set_printoptions(formatter={'int': hex})

Sbox = np.array(
	[[0x63, 0x7C, 0x77, 0x7B, 0xF2, 0x6B, 0x6F, 0xC5, 0x30, 0x01, 0x67, 0x2B, 0xFE, 0xD7, 0xAB, 0x76],
	 [0xCA, 0x82, 0xC9, 0x7D, 0xFA, 0x59, 0x47, 0xF0, 0xAD, 0xD4, 0xA2, 0xAF, 0x9C, 0xA4, 0x72, 0xC0],
	 [0xB7, 0xFD, 0x93, 0x26, 0x36, 0x3F, 0xF7, 0xCC, 0x34, 0xA5, 0xE5, 0xF1, 0x71, 0xD8, 0x31, 0x15],
	 [0x04, 0xC7, 0x23, 0xC3, 0x18, 0x96, 0x05, 0x9A, 0x07, 0x12, 0x80, 0xE2, 0xEB, 0x27, 0xB2, 0x75],
	 [0x09, 0x83, 0x2C, 0x1A, 0x1B, 0x6E, 0x5A, 0xA0, 0x52, 0x3B, 0xD6, 0xB3, 0x29, 0xE3, 0x2F, 0x84],
	 [0x53, 0xD1, 0x00, 0xED, 0x20, 0xFC, 0xB1, 0x5B, 0x6A, 0xCB, 0xBE, 0x39, 0x4A, 0x4C, 0x58, 0xCF],
	 [0xD0, 0xEF, 0xAA, 0xFB, 0x43, 0x4D, 0x33, 0x85, 0x45, 0xF9, 0x02, 0x7F, 0x50, 0x3C, 0x9F, 0xA8],
	 [0x51, 0xA3, 0x40, 0x8F, 0x92, 0x9D, 0x38, 0xF5, 0xBC, 0xB6, 0xDA, 0x21, 0x10, 0xFF, 0xF3, 0xD2],
	 [0xCD, 0x0C, 0x13, 0xEC, 0x5F, 0x97, 0x44, 0x17, 0xC4, 0xA7, 0x7E, 0x3D, 0x64, 0x5D, 0x19, 0x73],
	 [0x60, 0x81, 0x4F, 0xDC, 0x22, 0x2A, 0x90, 0x88, 0x46, 0xEE, 0xB8, 0x14, 0xDE, 0x5E, 0x0B, 0xDB],
	 [0xE0, 0x32, 0x3A, 0x0A, 0x49, 0x06, 0x24, 0x5C, 0xC2, 0xD3, 0xAC, 0x62, 0x91, 0x95, 0xE4, 0x79],
	 [0xE7, 0xC8, 0x37, 0x6D, 0x8D, 0xD5, 0x4E, 0xA9, 0x6C, 0x56, 0xF4, 0xEA, 0x65, 0x7A, 0xAE, 0x08],
	 [0xBA, 0x78, 0x25, 0x2E, 0x1C, 0xA6, 0xB4, 0xC6, 0xE8, 0xDD, 0x74, 0x1F, 0x4B, 0xBD, 0x8B, 0x8A],
	 [0x70, 0x3E, 0xB5, 0x66, 0x48, 0x03, 0xF6, 0x0E, 0x61, 0x35, 0x57, 0xB9, 0x86, 0xC1, 0x1D, 0x9E],
	 [0xE1, 0xF8, 0x98, 0x11, 0x69, 0xD9, 0x8E, 0x94, 0x9B, 0x1E, 0x87, 0xE9, 0xCE, 0x55, 0x28, 0xDF],
	 [0x8C, 0xA1, 0x89, 0x0D, 0xBF, 0xE6, 0x42, 0x68, 0x41, 0x99, 0x2D, 0x0F, 0xB0, 0x54, 0xBB, 0x16]])

RCon = np.array([[0x00, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36],
                 [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00],
                 [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00],
                 [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]])


class AES:
	"""AES key"""

	def __init__(self, pairKeyNonce: PairKeyNonce):
		"""
		:param key: int (128 bit)
		:param nonce: int (64 bit)
		"""
		self.key = pairKeyNonce.key
		self.nonce = pairKeyNonce.nonce
		self.counter = 0

	def increment_counter(self):
		self.counter += 1

	def ctrnonce_encryption(self):
		"""
		Block cipher encryption with AES of
		the countered nonce
		:param noncectr: int (16 characters long)
		:return: bytearray
		"""
		key_state = AES.tostate(self.key.to_bytes(16, byteorder='big'))
		state = AES.tostate(self.nonce.to_bytes(8, byteorder='big') + self.counter.to_bytes(8, byteorder='big'))
		AES.aes_encrypt(state, key_state)
		c = bytes(state.flatten('F').tolist())
		return c

	def aes_ctrmode_encrypt(self, m):
		"""
		Encrypt using aes with counter mode
		:param m: bytearray to encrypt
		:return: ciphertext as bytearray
		"""
		nb_blocks = int(math.ceil(len(m) / 16))
		blocks_results = [None] * nb_blocks
		for i in range(nb_blocks):
			c = self.ctrnonce_encryption()

			self.increment_counter()
			if i != nb_blocks:
				block = m[i * 16: (i + 1) * 16]
			else:
				block = m[i * 16:] + [0] * (len(m) % 16)
			result = AES.xor_bytes(block, c)
			blocks_results[i] = result
		result = b"".join(blocks_results)
		return result[:len(m)]

	@staticmethod
	def xor_bytes(bytes1, bytes2):
		result = []
		for i in range(len(bytes1)):
			result.append(bytes1[i] ^ bytes2[i])
		return bytes(result)

	@staticmethod
	def aes_encrypt(state, key):
		"""
		Encrypt state
		:param state: 4*4 numpy array of ints
		:param key: 4*4 numpy array of ints
		"""
		expandedkey = AES.keyexpansion(key)
		AES.addroundkey(state, expandedkey[:, : 4])
		for i in range(1, 10):
			AES.bytesub(state)
			AES.shiftrow(state)
			AES.mixcolumn(state)
			AES.addroundkey(state, expandedkey[:, 4 * i:4 * i + 4])
		AES.bytesub(state)
		AES.shiftrow(state)
		AES.addroundkey(state, expandedkey[:, 4 * 10:4 * 10 + 4])
		return state

	@staticmethod
	def keyexpansion(key):
		"""
		:param key: 4*4 numpy array of ints (like state)
		:return: w, expanded key: 4*44 numpy array of ints
		"""
		w = key.copy()

		for i in range(4, 44):
			temp = w[:, i - 1]
			if i % 4 == 0:
				temp = AES.xorcolumns(AES.subword(AES.rotword(temp)), RCon[:, int(i / 4)])
			newcol = np.array(AES.xorcolumns(w[:, i - 4], temp))
			w = np.append(w, newcol[:, None], axis=1)

		return w

	@staticmethod
	def rotword(word):
		"""
		:param word: array
		:return: array, word but shifted 1 to left
		"""
		return np.append(word[1:], word[:1])

	@staticmethod
	def subword(word):
		"""
		:param word: array
		:return: array, word with sbox applied on every element
		"""
		result = []
		for i in range(4):
			result.append(AES.applysbox(word[i]))
		return result

	@staticmethod
	def bytesub(state):
		"""
		Apply sbox on every element in state
		:param state: 4*4 numpy array of ints
		"""
		for i in range(4):  # for every row
			for j in range(4):  # for every element in row
				state[i, j] = AES.applysbox(state[i, j])

	@staticmethod
	def applysbox(val):
		"""
		:param val: int
		:return: int, result of val applied on sbox
		"""
		hexval = hex(val)[2:].zfill(2)
		x = hexval[0]
		y = hexval[1]
		return Sbox[int(x, 16), int(y, 16)]

	@staticmethod
	def shiftrow(state):
		"""
		:param state: 4*4 numpy array of ints
		"""
		for row_i in range(4):
			state[row_i] = np.append(state[row_i, row_i:], state[row_i, :row_i])

	@staticmethod
	def mixcolumn(state):
		# Galois field, finit field with 8 bits numbers (0 to 255)
		gf1 = [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 38, 40, 42, 44, 46, 48, 50, 52,
		       54, 56, 58, 60, 62, 64, 66, 68, 70, 72, 74, 76, 78, 80, 82, 84, 86, 88, 90, 92, 94, 96, 98, 100, 102,
		       104, 106, 108, 110, 112, 114, 116, 118, 120, 122, 124, 126, 128, 130, 132, 134, 136, 138, 140, 142, 144,
		       146, 148, 150, 152, 154, 156, 158, 160, 162, 164, 166, 168, 170, 172,
		       174, 176, 178, 180, 182, 184, 186, 188, 190, 192, 194, 196, 198, 200, 202, 204, 206, 208, 210, 212, 214,
		       216, 218, 220, 222, 224, 226, 228, 230, 232, 234, 236, 238, 240, 242, 244, 246, 248, 250, 252, 254, 27,
		       25, 31, 29, 19, 17, 23, 21, 11, 9, 15, 13, 3, 1, 7, 5, 59, 57, 63, 61, 51, 49, 55, 53, 43, 41, 47, 45,
		       35, 33, 39, 37, 91, 89, 95, 93, 83, 81, 87, 85, 75, 73, 79, 77, 67,
		       65, 71, 69, 123, 121, 127, 125, 115, 113, 119, 117, 107, 105, 111, 109, 99, 97, 103, 101, 155, 153, 159,
		       157, 147, 145, 151, 149, 139, 137, 143, 141, 131, 129, 135, 133, 187, 185, 191, 189, 179, 177, 183, 181,
		       171, 169, 175, 173, 163, 161, 167, 165, 219, 217, 223, 221, 211, 209, 215, 213, 203, 201, 207, 205, 195,
		       193, 199, 197, 251, 249, 255, 253, 243, 241, 247, 245, 235, 233,
		       239, 237, 227, 225, 231, 229]
		# Another galois field, finit field with 8 bits numbers (0 to 255)
		gf2 = [0, 3, 6, 5, 12, 15, 10, 9, 24, 27, 30, 29, 20, 23, 18, 17, 48, 51, 54, 53, 60, 63, 58, 57, 40, 43, 46,
		       45, 36, 39, 34, 33, 96, 99, 102, 101, 108, 111, 106, 105, 120, 123, 126, 125, 116, 119, 114, 113, 80, 83,
		       86, 85, 92, 95, 90, 89, 72, 75, 78, 77, 68, 71, 66, 65, 192, 195, 198, 197, 204, 207, 202, 201, 216, 219,
		       222, 221, 212, 215, 210, 209, 240, 243, 246, 245, 252, 255, 250,
		       249, 232, 235, 238, 237, 228, 231, 226, 225, 160, 163, 166, 165, 172, 175, 170, 169, 184, 187, 190, 189,
		       180, 183, 178, 177, 144, 147, 150, 149, 156, 159, 154, 153, 136, 139, 142, 141, 132, 135, 130, 129, 155,
		       152, 157, 158, 151, 148, 145, 146, 131, 128, 133, 134, 143, 140, 137, 138, 171, 168, 173, 174, 167, 164,
		       161, 162, 179, 176, 181, 182, 191, 188, 185, 186, 251, 248, 253,
		       254, 247, 244, 241, 242, 227, 224, 229, 230, 239, 236, 233, 234, 203, 200, 205, 206, 199, 196, 193, 194,
		       211, 208, 213, 214, 223, 220, 217, 218, 91, 88, 93, 94, 87, 84, 81, 82, 67, 64, 69, 70, 79, 76, 73, 74,
		       107, 104, 109, 110, 103, 100, 97, 98, 115, 112, 117, 118, 127, 124, 121, 122, 59, 56, 61, 62, 55, 52, 49,
		       50, 35, 32, 37, 38, 47, 44, 41, 42, 11, 8, 13, 14, 7, 4, 1, 2, 19,
		       16, 21, 22, 31, 28, 25, 26]

		stateLength = len(state)  # number of column
		col = [None] * 4

		for i in range(stateLength):  # for each columns
			# for each line of each columns (symbol ^ means XOR)

			col[0] = gf1[state[0, i]] ^ gf2[state[1, i]] ^ state[2, i] ^ state[3, i]
			col[1] = state[0, i] ^ gf1[state[1, i]] ^ gf2[state[2, i]] ^ state[3, i]
			col[2] = state[0, i] ^ state[1, i] ^ gf1[state[2, i]] ^ gf2[state[3, i]]
			col[3] = gf2[state[0, i]] ^ state[1, i] ^ state[2, i] ^ gf1[state[3, i]]

			state[:, i] = col

	@staticmethod
	def addroundkey(state, roundkey):
		"""
		:param state: 4*4 numpy array of ints
		:param roundkey: 4*4 numpy array of ints
		:return: 4*4 numpy array of ints, result of columnwise xor of state with roundkey
		"""
		for i in range(4):
			state[:, i] = AES.xorcolumns(state[:, i], roundkey[:, i])

	@staticmethod
	def xorcolumns(col1, col2):
		"""
		:param col1: array
		:param col2: array
		:return: list, result of col1 xor col2
		"""
		col = [None] * 4
		for i in range(4):
			col[i] = col1[i] ^ col2[i]
		return col

	@staticmethod
	def tostate(m):
		"""
		:param m: 16 bytes array
		:return: 4*4 numpy array of ints
		"""
		state = []
		for row_i in range(4):  # for every row
			row = []
			for col_i in range(4):  # for every element in row
				x = m[row_i + 4 * col_i]
				row.append(x)
			state.append(row)
		return np.array(state)
