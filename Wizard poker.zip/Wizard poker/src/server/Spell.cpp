#include "server/Spell.hpp"

bool Spell::isCreature()
{
	return false;
}

bool Spell::isSpell()
{
	return true;
}
