#ifndef _CARD_CLIENT_HPP
#define _CARD_CLIENT_HPP

class ClientCard
{
	public:
		typedef int64_t ID;
};

#endif  // _CARD_CLIENT_HPP
